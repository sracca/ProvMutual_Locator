<?php
/**
 * Providence Mutual Agent Locator
 * Database Info/Credentials
 *Author: Stephanie Racca
 * Date Created: 7/27/17
 * Last Update: //
 */

//Add this in later
$username="username";
$password="password";
$database="username=databaseName";
?>
